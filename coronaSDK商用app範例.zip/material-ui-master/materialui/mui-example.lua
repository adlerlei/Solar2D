--
-- mui-example template module, extend mui
--

-- mui
local muiData = require( "materialui.mui-data" )

local mathFloor = math.floor
local mathMod = math.fmod
local mathABS = math.abs
local mathCeil = math.ceil

local M = muiData.M -- {} -- for module array/table

-- define methods here
--[[--
function M.exampleMethod()

end
--]]--

return M
